.MODEL SMALL
.STACK 100H
.DATA
    MSG1 DB 'Name: Minahil Tanveer', 0DH,0AH,'$'
    MSG2 DB 'SAP ID: 69092', 0DH,0AH,'$'
.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX

    ; Print Name
    MOV DX, OFFSET MSG1
    MOV AH, 09H
    INT 21H

    ; Print SAP ID
    MOV DX, OFFSET MSG2
    MOV AH, 09H
    INT 21H

    MOV AH, 4CH
    INT 21H
MAIN ENDP
END MAIN



